CREATE FUNCTION newid()
  RETURNS VARCHAR(32)
  return replace(uuid(), '-', '');
